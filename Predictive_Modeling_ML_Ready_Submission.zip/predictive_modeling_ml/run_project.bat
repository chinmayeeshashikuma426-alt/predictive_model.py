@echo off
python -m pip install -r requirements.txt
python predictive_model.py
pause
